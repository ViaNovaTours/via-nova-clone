import React from "react";

export default function CustomerCommunication({ order, onUpdate }) {
  return null;
}