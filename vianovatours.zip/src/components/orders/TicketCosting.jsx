import React from "react";

export default function TicketCosting({ order, onUpdate }) {
    return null;
}